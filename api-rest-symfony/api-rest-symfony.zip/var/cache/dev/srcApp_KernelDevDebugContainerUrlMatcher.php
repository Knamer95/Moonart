<?php

use Symfony\Component\Routing\Matcher\Dumper\PhpMatcherTrait;
use Symfony\Component\Routing\RequestContext;

/**
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class srcApp_KernelDevDebugContainerUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    use PhpMatcherTrait;

    public function __construct(RequestContext $context)
    {
        $this->context = $context;
        $this->staticRoutes = [
            '/user' => [[['_route' => 'user', '_controller' => 'App\\Controller\\UserController::index'], null, ['POST' => 0], null, false, false, null]],
            '/register' => [[['_route' => 'register_user', '_controller' => 'App\\Controller\\UserController::newUser'], null, ['POST' => 0], null, false, false, null]],
            '/login' => [[['_route' => 'login_user', '_controller' => 'App\\Controller\\UserController::login'], null, ['POST' => 0], null, false, false, null]],
            '/user/update_user' => [[['_route' => 'update_user', '_controller' => 'App\\Controller\\UserController::update'], null, ['PUT' => 0], null, false, false, null]],
            '/user/update_config' => [[['_route' => 'update_config', '_controller' => 'App\\Controller\\UserController::setConfig'], null, ['PUT' => 0], null, false, false, null]],
            '/user/get_config' => [[['_route' => 'get_config', '_controller' => 'App\\Controller\\UserController::getConfig'], null, ['GET' => 0], null, false, false, null]],
            '/user/get_user' => [[['_route' => 'get_user', '_controller' => 'App\\Controller\\UserController::getUserByNick'], null, ['GET' => 0], null, false, false, null]],
            '/user/check_password' => [[['_route' => 'check_password', '_controller' => 'App\\Controller\\UserController::comparePwd'], null, ['POST' => 0], null, false, false, null]],
            '/image' => [[['_route' => 'image', '_controller' => 'App\\Controller\\ImageController::index'], null, null, null, false, false, null]],
            '/image/new' => [[['_route' => 'upload_image', '_controller' => 'App\\Controller\\ImageController::upload'], null, ['POST' => 0], null, false, false, null]],
            '/image/list' => [[['_route' => 'list_images', '_controller' => 'App\\Controller\\ImageController::images'], null, ['GET' => 0], null, false, false, null]],
            '/image/list/all' => [[['_route' => 'list_all', '_controller' => 'App\\Controller\\ImageController::allImages'], null, ['GET' => 0], null, false, false, null]],
            '/image/search' => [[['_route' => 'search_images', '_controller' => 'App\\Controller\\ImageController::searchImages'], null, ['GET' => 0], null, false, false, null]],
            '/image/faved' => [[['_route' => 'list_faved', '_controller' => 'App\\Controller\\ImageController::interactedUser'], null, ['GET' => 0], null, false, false, null]],
            '/image/details' => [[['_route' => 'image_details', '_controller' => 'App\\Controller\\ImageController::details'], null, ['GET' => 0], null, false, false, null]],
            '/user/feed' => [[['_route' => 'shared_images', '_controller' => 'App\\Controller\\ImageController::sharedImages'], null, ['GET' => 0], null, false, false, null]],
            '/create_interaction' => [[['_route' => 'create_interaction', '_controller' => 'App\\Controller\\InteractionsController::interact'], null, ['POST' => 0], null, false, false, null]],
            '/update_interaction' => [[['_route' => 'update_interaction', '_controller' => 'App\\Controller\\InteractionsController::interact'], null, ['PUT' => 0], null, false, false, null]],
            '/check' => [[['_route' => 'check', '_controller' => 'App\\Controller\\InteractionsController::check'], null, ['POST' => 0], null, false, false, null]],
            '/image/interactions' => [[['_route' => 'get_image_interactions', '_controller' => 'App\\Controller\\InteractionsController::countInteractions'], null, ['GET' => 0], null, false, false, null]],
            '/user/follow-unfollow' => [[['_route' => 'follow_unfollow', '_controller' => 'App\\Controller\\FollowController::follow'], null, ['POST' => 0], null, false, false, null]],
            '/user/get-follow' => [[['_route' => 'get_is_following', '_controller' => 'App\\Controller\\FollowController::getIsFollowing'], null, ['GET' => 0], null, false, false, null]],
            '/user/get-user-follows' => [[['_route' => 'get_number_follows', '_controller' => 'App\\Controller\\FollowController::getFollowInfo'], null, ['GET' => 0], null, false, false, null]],
            '/image/add-comment' => [[['_route' => 'add_comment', '_controller' => 'App\\Controller\\ImageCommentController::addComment'], null, ['POST' => 0], null, false, false, null]],
            '/image/get-comments' => [[['_route' => 'get_comments', '_controller' => 'App\\Controller\\ImageCommentController::getComments'], null, ['GET' => 0], null, false, false, null]],
        ];
        $this->regexpList = [
            0 => '{^(?'
                    .'|/image/(?'
                        .'|update/([^/]++)(*:32)'
                        .'|remove/([^/]++)(*:54)'
                        .'|hide/([^/]++)(*:74)'
                        .'|comment/remove/([^/]++)(*:104)'
                    .')'
                    .'|/user/image/([^/]++)(*:133)'
                .')/?$}sDu',
        ];
        $this->dynamicRoutes = [
            32 => [[['_route' => 'update_image', '_controller' => 'App\\Controller\\ImageController::upload'], ['id'], ['PUT' => 0], null, false, true, null]],
            54 => [[['_route' => 'remove_image', '_controller' => 'App\\Controller\\ImageController::remove'], ['id'], ['DELETE' => 0], null, false, true, null]],
            74 => [[['_route' => 'hide_image', '_controller' => 'App\\Controller\\ImageController::hide'], ['id'], ['PUT' => 0], null, false, true, null]],
            104 => [[['_route' => 'remove_comment', '_controller' => 'App\\Controller\\ImageCommentController::removeComment'], ['id'], ['DELETE' => 0], null, false, true, null]],
            133 => [[['_route' => 'user_by_image', '_controller' => 'App\\Controller\\ImageController::userByImage'], ['id'], ['GET' => 0], null, false, true, null]],
        ];
    }
}
